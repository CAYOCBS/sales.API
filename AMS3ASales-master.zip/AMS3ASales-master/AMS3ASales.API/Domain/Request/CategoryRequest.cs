﻿namespace AMS3ASales.API.Domain.Request
{
    public class CategoryRequest
    {
        public string Description { get; set; }
        public string ImageURL { get; set; }
    }
}
